Feign Benchmarks
===================

This module includes [JMH](http://openjdk.java.net/projects/code-tools/jmh/) benchmarks for Feign.

=== Building the benchmark
Install and run `mvn -Dfeign.version=8.1.0` to produce `target/benchmark` pinned to version `8.1.0`

=== Running the benchmark
Execute `target/benchmark`
