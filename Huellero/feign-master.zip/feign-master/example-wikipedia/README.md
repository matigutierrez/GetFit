Wikipedia Example
===================

This is an example of advanced json response parsing, including pagination.

=== Building example with Gradle
Install and run `gradle` to produce `build/wikipedia`

=== Building example with Maven
Install and run `mvn` to produce `target/wikipedia`
