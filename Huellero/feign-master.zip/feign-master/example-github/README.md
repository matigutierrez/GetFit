GitHub Example
===================

This is an example of a simple json client.

=== Building example with Gradle
Install and run `gradle` to produce `build/github`

=== Building example with Maven
Install and run `mvn` to produce `target/github`
